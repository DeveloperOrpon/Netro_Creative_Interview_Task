package com.example.netro_creative_interview_work

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
