const String appSplashUrl="assets/images/Splash.png";
const String googleIcon="assets/icon/googleIcon.svg";
const String faceBookIcon="assets/icon/facebookIcon.svg";


