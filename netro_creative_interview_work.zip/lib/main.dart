import 'package:flutter/material.dart';

import 'app_init.dart';
import 'common/config/appConfig.dart';

void main() {
  runApp(const MainApp());
  initLoading();
}


