
const String BASE_URL="https://travelo-api.products8.xyz/api/";
const String SIGN_UP="register";
const String SIGN_IN="login";
const String OTP_VERIFY="verify_otp";